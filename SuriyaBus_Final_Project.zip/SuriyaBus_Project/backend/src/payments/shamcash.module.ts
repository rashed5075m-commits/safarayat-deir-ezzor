import { Module } from '@nestjs/common';
import { ShamCashService } from './shamcash.service';
import { ShamCashController } from './shamcash.controller';

@Module({
  providers: [ShamCashService],
  controllers: [ShamCashController],
  exports: [ShamCashService],
})
export class ShamCashModule {}
