import { Injectable } from '@nestjs/common';

@Injectable()
export class ShamCashService {
  async initiatePayment(amount: number, phoneNumber: string) {
    // Simulate API call to ShamCash
    console.log(`Initiating ShamCash payment for ${amount} to ${phoneNumber}`);
    return {
      success: true,
      transaction_id: `SHAM_${Math.random().toString(36).substring(7).toUpperCase()}`,
      status: 'PENDING',
    };
  }

  async verifyPayment(transactionId: string) {
    // In simulation, we always return true
    return {
      success: true,
      status: 'PAID',
    };
  }
}
