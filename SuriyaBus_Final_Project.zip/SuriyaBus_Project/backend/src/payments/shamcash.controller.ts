import { Controller, Post, Body, UseGuards, Get, Param } from '@nestjs/common';
import { ShamCashService } from './shamcash.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { CurrentUser } from '../common/decorators/current-user.decorator';

@Controller('payments/shamcash')
export class ShamCashController {
  constructor(private readonly shamCashService: ShamCashService) {}

  @UseGuards(JwtAuthGuard)
  @Post('initiate')
  async initiate(@Body() body: { amount: number; phoneNumber: string }, @CurrentUser() user: any) {
    // هنا يتم التواصل مع خدمة شام كاش
    return this.shamCashService.initiatePayment(body.amount, body.phoneNumber);
  }

  @Get('verify/:transactionId')
  async verify(@Param('transactionId') transactionId: string) {
    return this.shamCashService.verifyPayment(transactionId);
  }

  @Post('webhook')
  async handleWebhook(@Body() payload: any) {
    // هذه النقطة تستقبل التأكيد التلقائي من سيرفر شام كاش
    console.log('Received ShamCash Webhook:', payload);
    return { received: true };
  }
}
