import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { CompaniesModule } from './companies/companies.module';
import { BusesModule } from './buses/buses.module';
import { TripsModule } from './trips/trips.module';
import { BookingModule } from './booking/booking.module';
import { ShamCashModule } from './payments/shamcash.module';
import { PrismaService } from './prisma.service';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    AuthModule,
    CompaniesModule,
    BusesModule,
    TripsModule,
    BookingModule,
    ShamCashModule,
  ],
  providers: [PrismaService],
})
export class AppModule {}
