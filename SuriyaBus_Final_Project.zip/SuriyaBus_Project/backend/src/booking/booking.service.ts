import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { Cron, CronExpression } from '@nestjs/schedule';
import { SeatStatus } from '@prisma/client';

@Injectable()
export class BookingService {
  constructor(private prisma: PrismaService) {}

  async getTripSeats(tripId: string) {
    return this.prisma.tripSeat.findMany({
      where: { tripId },
      orderBy: { seatNumber: 'asc' },
    });
  }

  async holdSeat(tripId: string, seatNumber: number, userId: string) {
    const heldUntil = new Date();
    heldUntil.setMinutes(heldUntil.getMinutes() + 10);

    return this.prisma.tripSeat.update({
      where: { tripId_seatNumber: { tripId, seatNumber } },
      data: {
        status: SeatStatus.HELD,
        heldUntil: heldUntil,
      },
    });
  }

  async confirmBooking(data: any) {
    const { tripId, seatNumbers, userId, paymentMethod } = data;
    
    // Create booking
    const trip = await this.prisma.trip.findUnique({ where: { id: tripId } });
    const booking = await this.prisma.booking.create({
      data: {
        tripId,
        userId,
        seatNumbers,
        totalPrice: trip.price * seatNumbers.length,
        paymentMethod,
        paymentStatus: 'PAID', // In simulation mode
        qrCode: `QR_BOOKING_${Date.now()}`,
      },
    });

    // Update seats
    await this.prisma.tripSeat.updateMany({
      where: {
        tripId,
        seatNumber: { in: seatNumbers },
      },
      data: {
        status: SeatStatus.BOOKED,
        bookingId: booking.id,
      },
    });

    return booking;
  }

  @Cron(CronExpression.EVERY_MINUTE)
  async handleCron() {
    const now = new Date();
    const expiredSeats = await this.prisma.tripSeat.updateMany({
      where: {
        status: SeatStatus.HELD,
        heldUntil: { lt: now },
      },
      data: {
        status: SeatStatus.AVAILABLE,
        heldUntil: null,
      },
    });
  }
  
  async releaseSeat(tripId: string, seatNumber: number) {
      return this.prisma.tripSeat.update({
          where: { tripId_seatNumber: { tripId, seatNumber } },
          data: {
              status: SeatStatus.AVAILABLE,
              heldUntil: null
          }
      });
  }
}
