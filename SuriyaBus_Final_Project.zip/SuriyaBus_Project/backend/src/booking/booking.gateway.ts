import {
  WebSocketGateway,
  SubscribeMessage,
  MessageBody,
  WebSocketServer,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { BookingService } from './booking.service';

@WebSocketGateway({
  namespace: '/seats',
  cors: { origin: '*' },
})
export class BookingGateway {
  @WebSocketServer()
  server: Server;

  constructor(private readonly bookingService: BookingService) {}

  @SubscribeMessage('joinTrip')
  async handleJoinTrip(
    @MessageBody() tripId: string,
    @ConnectedSocket() client: Socket,
  ) {
    client.join(tripId);
    const seats = await this.bookingService.getTripSeats(tripId);
    client.emit('seatsStatus', seats);
  }

  @SubscribeMessage('holdSeat')
  async handleHoldSeat(
    @MessageBody() data: { tripId: string; seatNumber: number; userId: string },
  ) {
    await this.bookingService.holdSeat(data.tripId, data.seatNumber, data.userId);
    const seats = await this.bookingService.getTripSeats(data.tripId);
    this.server.to(data.tripId).emit('seatsStatus', seats);
  }

  @SubscribeMessage('releaseSeat')
  async handleReleaseSeat(
    @MessageBody() data: { tripId: string; seatNumber: number },
  ) {
    await this.bookingService.releaseSeat(data.tripId, data.seatNumber);
    const seats = await this.bookingService.getTripSeats(data.tripId);
    this.server.to(data.tripId).emit('seatsStatus', seats);
  }
}
