import { Controller, Get, Post, Body, Patch, Param, Query, UseGuards, UseInterceptors } from '@nestjs/common';
import { TripsService } from './trips.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CompanyIdInterceptor } from '../common/interceptors/company-id.interceptor';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { UserRole, TripStatus } from '@prisma/client';

@Controller('trips')
@UseGuards(JwtAuthGuard, RolesGuard)
export class TripsController {
  constructor(private readonly tripsService: TripsService) {}

  @Post()
  @Roles(UserRole.COMPANY_ADMIN, UserRole.SUPER_ADMIN)
  @UseInterceptors(CompanyIdInterceptor)
  create(@Body() createTripDto: any) {
    return this.tripsService.create(createTripDto);
  }

  @Get()
  findAll(@Query() query: any, @CurrentUser() user: any) {
    const filters: any = {};
    if (query.fromCity) filters.fromCity = query.fromCity;
    if (query.toCity) filters.toCity = query.toCity;
    if (query.companyId) filters.companyId = query.companyId;
    
    if (user && user.role !== UserRole.SUPER_ADMIN && user.role !== UserRole.USER) {
        filters.companyId = user.companyId;
    }

    return this.tripsService.findAll(filters);
  }

  @Patch(':id/cancel')
  @Roles(UserRole.COMPANY_ADMIN, UserRole.SUPER_ADMIN)
  cancel(@Param('id') id: string) {
    return this.tripsService.updateStatus(id, TripStatus.CANCELLED);
  }

  @Get(':id/seats')
  getSeats(@Param('id') id: string) {
    return this.tripsService.getSeats(id);
  }
}
