import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { TripStatus } from '@prisma/client';

@Injectable()
export class TripsService {
  constructor(private prisma: PrismaService) {}

  async create(data: any) {
    const bus = await this.prisma.bus.findUnique({ where: { id: data.busId } });
    const trip = await this.prisma.trip.create({
      data: {
        ...data,
        departureAt: new Date(data.departureAt),
        arrivalAt: new Date(data.arrivalAt),
      },
    });

    // Create seats
    const seats = [];
    for (let i = 1; i <= bus.capacity; i++) {
      seats.push({
        tripId: trip.id,
        seatNumber: i,
        status: 'AVAILABLE',
      });
    }
    await this.prisma.tripSeat.createMany({ data: seats });

    return trip;
  }

  findAll(where: any) {
    return this.prisma.trip.findMany({ 
        where,
        include: { company: true, bus: true }
    });
  }

  updateStatus(id: string, status: TripStatus) {
    return this.prisma.trip.update({
      where: { id },
      data: { status },
    });
  }

  getSeats(tripId: string) {
    return this.prisma.tripSeat.findMany({
      where: { tripId },
      orderBy: { seatNumber: 'asc' },
    });
  }
}
