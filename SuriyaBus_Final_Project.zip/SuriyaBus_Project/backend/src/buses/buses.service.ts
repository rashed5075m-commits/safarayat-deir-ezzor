import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Injectable()
export class BusesService {
  constructor(private prisma: PrismaService) {}

  create(data: any) {
    return this.prisma.bus.create({ data });
  }

  findAll(where: any) {
    return this.prisma.bus.findMany({ where });
  }

  remove(id: string) {
    return this.prisma.bus.delete({ where: { id } });
  }
}
