import { Controller, Get, Post, Body, Param, Delete, UseGuards, UseInterceptors } from '@nestjs/common';
import { BusesService } from './buses.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CompanyIdInterceptor } from '../common/interceptors/company-id.interceptor';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { UserRole } from '@prisma/client';

@Controller('buses')
@UseGuards(JwtAuthGuard, RolesGuard)
@UseInterceptors(CompanyIdInterceptor)
export class BusesController {
  constructor(private readonly busesService: BusesService) {}

  @Post()
  @Roles(UserRole.COMPANY_ADMIN, UserRole.SUPER_ADMIN)
  create(@Body() createBusDto: any) {
    return this.busesService.create(createBusDto);
  }

  @Get()
  findAll(@CurrentUser() user: any) {
    if (user.role === UserRole.SUPER_ADMIN) {
        return this.busesService.findAll({});
    }
    return this.busesService.findAll({ companyId: user.companyId });
  }

  @Delete(':id')
  @Roles(UserRole.COMPANY_ADMIN, UserRole.SUPER_ADMIN)
  remove(@Param('id') id: string) {
    return this.busesService.remove(id);
  }
}
