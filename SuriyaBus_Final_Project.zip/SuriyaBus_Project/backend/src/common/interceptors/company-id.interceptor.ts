import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { UserRole } from '@prisma/client';

@Injectable()
export class CompanyIdInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (user && user.role !== UserRole.SUPER_ADMIN && user.companyId) {
      if (request.method === 'POST' || request.method === 'PATCH' || request.method === 'PUT') {
        if (request.body) {
          request.body.companyId = user.companyId;
        }
      } else if (request.method === 'GET') {
        request.query.companyId = user.companyId;
      }
    }

    return next.handle();
  }
}
