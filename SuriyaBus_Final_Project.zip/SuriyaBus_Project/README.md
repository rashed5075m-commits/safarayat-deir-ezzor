# نظام حجز الباصات المتكامل (Bus Booking System)

هذا المشروع هو نظام متكامل لإدارة حجز حافلات النقل البري، يدعم تعدد الشركات، الحجز المباشر بالوقت الحقيقي، وتكامل مع بوابة دفع شام كاش (ShamCash).

## الهيكل التقني
- **Backend**: NestJS + Prisma + PostgreSQL (Supabase) + Socket.io
- **Frontend**: Next.js 14 (App Router) + Tailwind CSS + WebSocket Client
- **Database**: PostgreSQL

## المتطلبات المسبقة
- Node.js (v18+)
- PostgreSQL (أو حساب في Supabase)

## البدء محلياً

### 1. إعداد الخلفية (Backend)
```bash
cd backend
npm install
cp .env.example .env
# قم بتعديل .env بمعلومات قاعدة البيانات الخاصة بك
npx prisma generate
npx prisma db push
npm run start:dev
```

### 2. إعداد الواجهة الأمامية (Frontend)
```bash
cd frontend
npm install
npm run dev
```

## إنشاء أول مستخدم (سوبر أدمن)
بما أن النظام لا يسمح بإنشاء سوبر أدمن من الواجهة العامة لأسباب أمنية، استخدم SQL في Supabase Dashboard:
```sql
INSERT INTO "User" (id, email, password, role, name)
VALUES (gen_random_uuid(), 'admin@admin.com', '$2a$10$YourHashedPassword', 'SUPER_ADMIN', 'Main Admin');
```
*ملاحظة: يجب عمل Hash لكلمة المرور باستخدام bcrypt.*

## النشر (Deployment)

### Backend (Render.com)
1. اربط مستودع GitHub بـ Render.
2. اختر "Web Service".
3. Build Command: `npm install && npm run build`
4. Start Command: `npm run start:prod`
5. أضف متغيرات البيئة من ملف `.env`.

### Frontend (Vercel)
1. اربط مستودع GitHub بـ Vercel.
2. أضف `NEXT_PUBLIC_API_URL` و `NEXT_PUBLIC_SOCKET_URL`.
3. Deploy.

## استخدام النظام
1. **السوبر أدمن**: يدخل لإنشاء الشركات (Companies).
2. **مدير الشركة**: يسجل الدخول، يضيف الباصات (Buses)، ثم ينشئ الرحلات (Trips).
3. **المسافر**: يبحث عن رحلة، يختار المقاعد (تظهر الحالة بالوقت الحقيقي عبر Socket.io)، ثم يدفع عبر شام كاش أو نقداً.
