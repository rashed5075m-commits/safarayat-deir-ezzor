'use client';

import { useState, useEffect } from 'react';
import { SeatMap } from '@/components/SeatMap';
import { toast } from 'react-hot-toast';

export default function TripDetails({ params }: { params: { id: string } }) {
  const [selectedSeats, setSelectedSeats] = useState<number[]>([]);
  const [seats, setSeats] = useState<any[]>([]);

  useEffect(() => {
    // محاكاة تحميل المقاعد من السيرفر
    const initialSeats = Array.from({ length: 32 }, (_, i) => ({
      id: `${i}`,
      seatNumber: i + 1,
      status: Math.random() > 0.8 ? 'BOOKED' : 'AVAILABLE'
    }));
    setSeats(initialSeats);
  }, [params.id]);

  const handleSeatClick = (seat: any) => {
    if (seat.status === 'BOOKED') return;
    
    if (selectedSeats.includes(seat.seatNumber)) {
      setSelectedSeats(selectedSeats.filter(s => s !== seat.seatNumber));
    } else {
      if (selectedSeats.length >= 4) {
        toast.error('لا يمكنك حجز أكثر من 4 مقاعد في الرحلة الواحدة');
        return;
      }
      setSelectedSeats([...selectedSeats, seat.seatNumber]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
        <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
                <div className="bg-white p-6 rounded-2xl shadow-sm">
                    <h2 className="text-2xl font-bold mb-6 border-b pb-4">مخطط الباص</h2>
                    <SeatMap 
                        seats={seats} 
                        selectedSeats={selectedSeats} 
                        onSeatClick={handleSeatClick} 
                    />
                </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm h-fit">
                <h3 className="text-xl font-bold mb-4">ملخص الحجز</h3>
                <div className="space-y-3 mb-6">
                    <div className="flex justify-between">
                        <span>المقاعد المختارة:</span>
                        <span className="font-bold">{selectedSeats.join(', ') || 'لاشيء'}</span>
                    </div>
                    <div className="flex justify-between text-lg">
                        <span>الإجمالي:</span>
                        <span className="font-bold text-blue-600">{(selectedSeats.length * 25000).toLocaleString()} ل.س</span>
                    </div>
                </div>

                <div className="space-y-4">
                    <label className="block">
                        <span className="text-gray-700">رقم موبايل (شام كاش):</span>
                        <input type="tel" placeholder="09xxxxxxxx" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm border p-2" />
                    </label>
                    <button 
                        onClick={() => toast.success('تم الانتقال للدفع...')}
                        disabled={selectedSeats.length === 0}
                        className="w-full bg-green-600 text-white font-bold py-3 rounded-xl disabled:bg-gray-300"
                    >
                        دفع عبر شام كاش
                    </button>
                </div>
            </div>
        </div>
    </div>
  );
}
