'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function HomePage() {
  const [search, setSearch] = useState({ from: '', to: '', date: '' });
  const [trips, setTrips] = useState([
    { id: '1', fromCity: 'دمشق', toCity: 'حلب', price: 25000, departureAt: '2026-06-15T08:00:00' },
    { id: '2', fromCity: 'حمص', toCity: 'اللاذقية', price: 18000, departureAt: '2026-06-15T10:30:00' },
  ]);

  return (
    <main className="min-h-screen bg-gray-50">
      <nav className="bg-blue-900 text-white p-4 shadow-lg">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">باصات سوريا</h1>
          <div className="space-x-4 space-x-reverse">
            <Link href="/login" className="hover:underline">تسجيل الدخول</Link>
          </div>
        </div>
      </nav>

      <section className="container mx-auto py-12 px-4">
        <div className="bg-white p-8 rounded-2xl shadow-md max-w-4xl mx-auto -mt-20 relative z-10">
          <h2 className="text-xl font-bold mb-6 text-gray-800">احجز رحلتك القادمة</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <input type="text" placeholder="من مدينة..." className="p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" />
            <input type="text" placeholder="إلى مدينة..." className="p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" />
            <input type="date" className="p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" />
            <button className="bg-yellow-500 text-blue-900 font-bold p-3 rounded-lg hover:bg-yellow-400 transition">بحث</button>
          </div>
        </div>

        <div className="mt-12 max-w-4xl mx-auto">
          <h3 className="text-lg font-semibold mb-4">الرحلات المتاحة اليوم:</h3>
          <div className="space-y-4">
            {trips.map(trip => (
              <div key={trip.id} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex justify-between items-center">
                <div>
                  <div className="text-sm text-gray-500">من {trip.fromCity} إلى {trip.toCity}</div>
                  <div className="text-xl font-bold text-blue-900">{new Date(trip.departureAt).toLocaleTimeString('ar-SY')}</div>
                </div>
                <div className="text-right">
                  <div className="text-green-600 font-bold text-lg">{trip.price.toLocaleString()} ل.س</div>
                  <Link href={`/trips/${trip.id}`} className="inline-block mt-2 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">اختيار المقعد</Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
