'use client';

import QRCode from 'react-qr-code';
import Link from 'next/link';

export default function ConfirmationPage() {
  return (
    <div className="min-h-screen bg-blue-900 flex items-center justify-center p-4">
      <div className="bg-white p-8 rounded-3xl shadow-2xl max-w-sm w-full text-center">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <svg className="w-12 h-12 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
          </svg>
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">تم الحجز بنجاح!</h2>
        <p className="text-gray-500 mb-8">يرجى إظهار الرمز التالي للموظف عند الصعود للباص</p>
        
        <div className="bg-gray-50 p-4 rounded-xl inline-block mb-8">
          <QRCode value="BOOKING_ID_12345" size={150} />
        </div>

        <div className="text-left space-y-2 text-sm mb-8">
            <div className="flex justify-between"><span>رقم الرحلة:</span> <b>#1024</b></div>
            <div className="flex justify-between"><span>الوقت:</span> <b>08:30 AM</b></div>
            <div className="flex justify-between"><span>المقاعد:</span> <b>12, 13</b></div>
        </div>

        <Link href="/" className="block w-full bg-blue-600 text-white font-bold py-3 rounded-xl">العودة للرئيسية</Link>
      </div>
    </div>
  );
}
