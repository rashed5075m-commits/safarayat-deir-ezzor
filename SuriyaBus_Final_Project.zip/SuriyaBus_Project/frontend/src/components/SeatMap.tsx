'use client';

import React from 'react';

interface Seat {
  id: string;
  seatNumber: number;
  status: 'AVAILABLE' | 'HELD' | 'BOOKED';
}

interface SeatMapProps {
  seats: Seat[];
  onSeatClick: (seat: Seat) => void;
  selectedSeats: number[];
}

export const SeatMap: React.FC<SeatMapProps> = ({ seats, onSeatClick, selectedSeats }) => {
  return (
    <div className="grid grid-cols-4 gap-4 p-4 border rounded-lg bg-gray-50 max-w-sm mx-auto">
      {seats.map((seat) => (
        <button
          key={seat.id}
          disabled={seat.status === 'BOOKED' || (seat.status === 'HELD' && !selectedSeats.includes(seat.seatNumber))}
          onClick={() => onSeatClick(seat)}
          className={`
            h-12 w-12 rounded-t-lg border-2 flex items-center justify-center transition-colors
            ${seat.status === 'BOOKED' ? 'bg-red-500 border-red-700 text-white' : ''}
            ${seat.status === 'HELD' ? 'bg-yellow-400 border-yellow-600 text-white' : ''}
            ${seat.status === 'AVAILABLE' ? 'bg-white border-gray-300 hover:border-blue-500' : ''}
            ${selectedSeats.includes(seat.seatNumber) ? 'bg-blue-500 border-blue-700 text-white' : ''}
          `}
        >
          {seat.seatNumber}
        </button>
      ))}
    </div>
  );
};
